from django.contrib import admin
from .models import *

admin.site.register(Product)
admin.site.register(MainCategory)
admin.site.register(Category)
admin.site.register(SubCategory)
admin.site.register(Brand)
admin.site.register(Source)