from django.db import models




class MainCategory(models.Model):
    name = models.CharField(max_length=500, unique=True)

    def __str__(self):
        return (self.name)

class Category(models.Model):
    maincategory = models.ForeignKey(MainCategory, on_delete=models.CASCADE)
    name = models.CharField(max_length=150, unique=True)

    def __str__(self):
        return (self.name)

class SubCategory(models.Model):
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    name = models.CharField(max_length=150, unique=True)

    def __str__(self):
        return (self.name)
    

class KeywordSearch(models.Model):
    subcategory = models.ForeignKey(SubCategory, on_delete=models.CASCADE)
    name = models.CharField(max_length=500, default=None, unique=True)

    def __str__(self):
        return (self.name)

class Brand(models.Model):
    name = models.CharField(max_length=5000)
    def __str__(self):
        return (self.name)


class Source(models.Model):
    name = models.CharField(max_length=500)
    img = models.ImageField(upload_to ='uploads/')
    def __str__(self):
        return (self.name)

class Product(models.Model):
    product_name = models.CharField(max_length=5000)
    price = models.IntegerField()
    desc = models.CharField(max_length=10000)
    source = models.ManyToManyField(Source)
    ratings = models.IntegerField()
    reviews = models.IntegerField()
    overall_ratings = models.FloatField()
    link = models.TextField()
    img_link = models.TextField()
    prating = models.IntegerField()
    nrating = models.IntegerField()
    maincategory = models.ForeignKey(MainCategory, on_delete=models.CASCADE, null=True)
    category = models.ForeignKey(Category, on_delete=models.CASCADE, null=True)
    subcategory = models.ForeignKey(SubCategory, on_delete=models.CASCADE, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    query = models.CharField(max_length=5000, default="searchitem")
    brand = models.ForeignKey(Brand, on_delete=models.CASCADE, null=True, default=1)


    def __str__(self):
        return (self.product_name) 
    
