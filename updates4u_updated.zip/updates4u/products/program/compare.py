from products.program.scrape import  headers, recomCalc
from products.models import Product
import requests
from bs4 import BeautifulSoup



def compareP(id):
    #Storing Main Datas
    fname =[]
    matchedProd = {}
    NewMatched = {}
    localSearch = False
    matchedProducts = []
    links= []
    finallink = []
    overall_rating = 5.0
    ratings = 0
    review = 0


    #Collecting Req Product Informations
    prod = Product.objects.get(id=id)
    productName = prod.product_name
    source = prod.source.all()[0].name
    sourceid = prod.source.all()[0].id
    category = prod.category.id


    

    if source == "Amazon":
        search = productName[0:65].replace('(', ' ').replace(')'," ").replace(" ", " ").replace('/', ' ').replace(',', ' ').replace('''"''', ' ').replace('|', ' ').replace('[', ' ').replace(']', ' ').replace('&', ' ')
        print("Source is Amazon")
        search = search.replace("  ", "") 
        url = f"https://www.flipkart.com/search?q={search}"
        print(url)
        r = requests.get(url, headers=headers)
        soup = BeautifulSoup(r.text, "lxml")

        #Collecting all product name
        nm = soup.find_all('a', attrs={'class', 's1Q9rs'})
        
        for n in nm[0:5]:
            product_name = n.get('title')
            link = n.get('href')
            fname.append(product_name)
            links.append(link)

        prodid = 0
        for l in links:
            l = "https://www.flipkart.com" + l
            r = requests.get(l, headers=headers)
            soup = BeautifulSoup(r.text, "lxml")

            # Finding Name for -----prName-----            
            try:
                prName = soup.find('span', attrs={'class':"B_NuCI"}).text

            except:
                print("Error in Name")

            # Finding Price for -----price-----
            try: 
                price = soup.find("div", class_="_30jeq3 _16Jk6d").text
                price = int(price.replace("₹", "").replace(",", ""))
            except:
                print("Unable to Find Price")


            # Finding Ratings/Reviews for -----ratings-----/------review------
            try:
                rev_ratings = soup.find_all("div", class_="_2afbiS")
                try:
                    ratings = rev_ratings[0].get_text()
                
                except IndexError:
                    print("Unable to Find Ratings, Trying another way")

                try:    
                    ratings = ratings.replace(" Ratings", "").replace(",", "").replace("&", "")

                except:
                    print("Ratings Unavailable")

                try:
                    review = rev_ratings[1].get_text()

                except:
                    print("Unable to Find Reviews, Trying another way")
                
                try:
                    review = rev_ratings[1].get_text()
                    review = review.replace(" Reviews", "").replace(",", "")

                except AttributeError:
                    print("Incomplete Data-Skipping to Another Way")



            except UnboundLocalError and IndexError:
                try:
                    print("Trying diffrent method")
                    rev_ratings = soup.find("span", class_="_2_R_DZ _2IRzS8").text
                    rev_ratings = rev_ratings.split("and")
                    ratings = int(rev_ratings[0].replace(" ratings", "").replace(",",""))
                    review = int(rev_ratings[1].replace(" reviews", "").replace(",","").replace(" ", ""))
                    print("Done with alternate try")

                except:
                    print("Invalid Product- Going to next product")
                    # continue 

            # Finding Overall_Rating for -----overall_rating-----
            try:
                overall_rating = float(soup.find("div", class_="_3LWZlK _138NNC").text)

            except AttributeError:
                try:
                    overall_rating = float(soup.find("div", class_="_2d4LTz").text)

                except AttributeError:
                    print("Error")
                    # continue

            # Finding Image Link for -----image_link-----
            try:
                image_link = soup.find("img", class_="_2r_T1I _396QI4")

                image_link = image_link.get("src")

            except AttributeError:
                try:
                    image_link = soup.find("img", class_="_386cs4 _2amPTt _3qGmMb")
                    image_link = image_link.get("src")
                
                except:
                    image_link = soup.find("img", class_="_396cs4 _2amPTt _3qGmMb")
                    image_link = image_link.get("src")


            try:
                reviewPercent = recomCalc(l)

                precommendation = reviewPercent[0]
                nrecommendation = reviewPercent[1]

            except:
                precommendation = 80
                nrecommendation = 20

            source = "/media/uploads/flipkart-logo-transparent-png-download-0.png"
            sourceName = "Flipkart"

            product = {'id': prodid, 'name':prName, 'price':price, 'source':source, 'overall_rating':overall_rating, 'ratings':ratings, 'sourcename':sourceName , 'review':review, 'img':image_link, 'link':l, 'precom':precommendation, 'nrecom':nrecommendation }
            matchedProducts.append(product)
            prodid += 1


    if source == 'Flipkart':
        search = productName[0:100].replace(" ", "+").replace('&', '%26').replace("'", "")
        search = search.replace("  ", "")
        url = f"https://www.amazon.in/s?k={search}"
        print(url)
        webpage = requests.get(url, headers=headers)
        soup = BeautifulSoup(webpage.content, 'html.parser')
        product_details = soup.find_all('h2', attrs={'class': "a-size-mini a-spacing-none a-color-base s-line-clamp-3"})

        #Getting Products Link****************************************************************************
        for i in product_details:

            i = i.find('a', attrs={'class':'a-link-normal s-underline-text s-underline-link-text s-link-style a-text-normal'})
            i = i.get('href')
            i = str(i)
            links.append(i)


        exc1 = "/sspa/clic"
        exc2 = "https://aa"

        c = 0
        for l in links:
            cond = l[0:10]

            if cond == exc1:
                links.pop(c)

            elif cond == exc2:
                links.pop(c)

            else:
                finallink.append(l)

            c = c + 1
        

        prodid = 0
        for l in finallink[0:5]:
            url = "https://www.amazon.in" + l
            webpage = requests.get(url, headers=headers)
            soup = BeautifulSoup(webpage.content, 'html.parser')
            o_rating =0
            ft_rating = 0

            #Getting Product Name
            product_name = soup.find('span', attrs={'class': "a-size-large product-title-word-break"}).text.strip()

            #Getting Product Image
            product_img = soup.find('div', attrs={'class': "imgTagWrapper"})
            import json
            img_option = json.loads(product_img.contents[1]['data-a-dynamic-image'])
            product_img = sorted(img_option.keys())[-1]
            

            try:
                #Getting Product Price
                product_price = soup.find('span', attrs={'class': "a-price-whole"}).text.replace(",", "")
            except:
                pass
            
            try:
            #Getting Overall Rating
                rating_rev = soup.find('span', attrs={'class': "reviewCountTextLinkedHistogram noUnderline"}).text.strip()
                o_rating = rating_rev.split(" ")
                o_rating = o_rating[0]

            #Getting Total Ratings
                t_ratings = soup.find('span', attrs={'id': 'acrCustomerReviewText'}).text.replace(" ratings", "").split(" ")
                ft_rating = int(t_ratings[0].replace(",", ""))

            #Getting Negative & Positive Rating
                pnrating = soup.find('span', attrs={'class': 'cr-widget-TitleRatingsAndHistogram'})
                star5 = pnrating.find('a', attrs={'class':'a-link-normal 5star'}).get('title').split(" ")[0]
                star4 = pnrating.find('a', attrs={'class':'a-link-normal 4star'}).get('title').split(" ")[0]
                star3 = pnrating.find('a', attrs={'class':'a-link-normal 3star'}).get('title').split(" ")[0]
                star2 = pnrating.find('a', attrs={'class':'a-link-normal 2star'}).get('title').split(" ")[0]
                star1 = pnrating.find('a', attrs={'class':'a-link-normal 1star'}).get('title').split(" ")[0]
                precom = int(star5.replace("%", "")) + int(star4.replace("%", ""))
                nrecom = int(star3.replace("%", "")) + int(star2.replace("%", "")) + int(star1.replace("%", ""))

            except:
                precom = 0
                nrecom = 0
            

            #Getting Product Description
            try:
                desc = soup.find('div', attrs={'class' : 'a-row feature'})
                try:
                    desc = desc.find('span').text
                except:
                    desc = desc.find('p').text

            except:
                desc = soup.find_all('div', attrs={'class' : 'aplus-module-wrapper aplus-3p-fixed-widthaplus-module-wrapper aplus-3p-fixed-width'})
                for d in desc:
                    d = d.find('div', attrs = {'class': 'a-spacing-base'}).text
                    desc =  d + d


            #Saving The Data
            product_price = product_price.replace(".", "")


            source = r'''\media\uploads\amazon-logo-amazon-icon-transparent-free-png.webp'''
            sourceName = "Amazon"

            product = {'id': prodid ,'name':product_name, 'price':product_price, 'source':source ,'overall_rating':o_rating, 'sourcename':sourceName, 'ratings':ft_rating, 'review':'10+', 'img':product_img, 'link':url, 'precom':precom, 'nrecom':nrecom }
            matchedProducts.append(product)
            prodid += 1


    return(matchedProducts)