import requests


with open ("updates4u\products\program" + "/" + "validproxies.txt", 'r') as f:
    proxies = f.read().split("\n")


site_to_check = ['http://www.amazon.in', 'http://www.flipkart.com/', 'http://www.google.com']


counter = 0

for site in site_to_check:
    try:
        print(f"Using the Proxy {proxies[counter]}")
        res = requests.get(site, proxies={"http":proxies[-counter],
                                          "https":proxies[-counter]})    
        print(res.status_code)

    except:
        print(Exception)
        print(("Failed"))
    
    finally:
        counter += 1

