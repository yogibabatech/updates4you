from bs4 import BeautifulSoup
import requests
from products.models import *
import time
import json


# ***************************Header for Scraping Data***********************************
headers = ({'User-Agent' : 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36', 'Accept-Language' : 'en-US, en;q=0.5'})


# ***************************NutriStar***********************************

def nutristr():
    url = "https://www.nutristar.in/"
    r = requests.get(url)
    soup = BeautifulSoup(r.text, "lxml")

    print(soup)


#***************************HealthKart***********************************

def healthKart(search):
    searchq = search.replace(" ","+")
    print(searchq)
    url = f"https://www.healthkart.com/search?txtQ=protein"
    print(url)
    r = requests.get(url)
    soup = BeautifulSoup(r.text, "html.parser")
    product_names = soup.find_all("a")
    print(product_names)

    print(product_names)


#***************************HealthXP***********************************

def healthXP():
    url = "https://healthxp.in/healthxp"
    r = requests.get(url)
    soup = BeautifulSoup(r.text, "lxml")

    print(soup)



#***************************HealthXP***********************************
def nutrabay():
    url = "https://nutrabay.com/st-search/?query=on%20nutrition"
    headers = ({'User-Agent' : 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36', 'Accept-Language' : 'en-US, en;q=0.5'})
    webpage = requests.get(url, headers=headers)
    soup = BeautifulSoup(webpage.content, 'html.parser')
    product_name = soup.find_all('p', attrs={'class': "name product-title"})
    

def drchoice():
    url = "https://thedrchoice.com/"
    r = requests.get(url)
    soup = BeautifulSoup(r.text, "lxml")

    print(soup)



#Scraping From Flipkart
def productcomp(search, category, count=100):
    product_main = []
    finp = search.replace(" ", "+")

    urlm = f"https://www.flipkart.com/search?q={finp}&otracker=search&otracker1=search&marketplace=FLIPKART&as-show=off&as=off&sort=popularity"
    r = requests.get(urlm, headers=headers)

    soup = BeautifulSoup(r.text, "lxml")


    name = soup.find_all("a", class_="s1Q9rs")
    link = soup.find_all("a", class_="s1Q9rs")

    v1name = soup.find_all("a", class_="IRpwTa")
    v1link = soup.find_all("a", class_="IRpwTa")

    v3name = soup.find_all("div", class_="_4rR01T")
    v3link = soup.find_all("a", class_="_1fQZEK")
    v3np = soup.find_all("a", class_="_1LKTO3")#New Page Link

    if name:
        for i in name:
            name= i.get("title")

        for i in link:
            name = i.get("href")
            product_main.append(name)

    elif v1name:
        for i in v1name:
            name= i.get("title")

        for i in v1link:
            name = i.get("href")
            product_main.append(name)

    elif v3name:
        for i in v3name:
            name= i.get("title")


        for i in v3link:
            name = i.get("href")
            product_main.append(name)


    else:
        print("Not Matched")

    

    for i in product_main:
        c = 0
        flipkartSingle(i, category, search)
        c = c+1
        if c == count:
            break

def flipkartSingle(i, category, search):
    url= "https://www.flipkart.com" + i
    r = requests.get(url, headers=headers)
    Cat = []
    soup = BeautifulSoup(r.text, "lxml")
    try:
        name = soup.find("span", class_="B_NuCI").text
    except:
        print("Unable to find name")

    try:    
        price = soup.find("div", class_="_30jeq3 _16Jk6d").text
        price = int(price.replace("₹", "").replace(",", ""))

    except:
        print("Unable to Find Price")

    try:
        rev_ratings = soup.find_all("div", class_="_2afbiS")
        try:
            ratings = rev_ratings[0].get_text()
        
        except IndexError:
            print("Unable to Find Ratings, Trying another way")

        try:    
            ratings = ratings.replace(" Ratings", "").replace(",", "").replace("&", "")

        except:
            print("Ratings Unavailable")

        try:
            review = rev_ratings[1].get_text()

        except:
            print("Unable to Find Reviews, Trying another way")
        
        try:
            review = rev_ratings[1].get_text()
            review = review.replace(" Reviews", "").replace(",", "")

        except AttributeError:
            print("Incomplete Data-Skipping to Another Way")



    except UnboundLocalError and IndexError:
        try:
            print("Trying diffrent method")
            rev_ratings = soup.find("span", class_="_2_R_DZ _2IRzS8").text
            rev_ratings = rev_ratings.split("and")
            ratings = int(rev_ratings[0].replace(" ratings", "").replace(",",""))
            review = int(rev_ratings[1].replace(" reviews", "").replace(",","").replace(" ", ""))
            print("Done with alternate try")

        except:
            print(Exception)
            print("Invalid Product- Going to next product")
            # continue


    try:
        overall_rating = float(soup.find("div", class_="_3LWZlK _138NNC").text)

    except AttributeError:
        try:
            overall_rating = float(soup.find("div", class_="_2d4LTz").text)

        except AttributeError:
            print("Error")
            # continue

    try:
        image_link = soup.find("img", class_="_2r_T1I _396QI4")

        image_link = image_link.get("src")

    except AttributeError:
        try:
            image_link = soup.find("img", class_="_386cs4 _2amPTt _3qGmMb")
            image_link = image_link.get("src")
        
        except:
            image_link = soup.find("img", class_="_396cs4 _2amPTt _3qGmMb")
            image_link = image_link.get("src")


    if int(overall_rating) >= 4 and int(ratings) >= 500 and int(review) >= 10:
        subcat_raw = SubCategory.objects.filter(name=category)
        subcat = subcat_raw[0]
        cat = subcat_raw[0].category
        maincat = cat.maincategory
        print(subcat)
        print(cat)
        print(maincat)

        reviewPercent = recomCalc(url)
        product = Product(
            product_name=name, 
            price=int(price), 
            ratings=int(ratings), 
            reviews=int(review), 
            overall_ratings = float(overall_rating), 
            link=url, 
            img_link=image_link, 
            query = search, 
            prating=reviewPercent[0],
            nrating=reviewPercent[1],
            maincategory=maincat,
            category=cat,
            subcategory=subcat,
            )
        product.save()
        Cat.append(cat)
        print(cat)

    return product


def flipkartProUp(link, id):
    headers={'Cache-Control': 'no-cache, must-revalidate'}
    r = requests.get(link.format(rn=time.time()), headers=headers)
    soup = BeautifulSoup(r.text, "lxml")
    try:
        try:
            name = soup.find("span", class_="B_NuCI").text

        except:
            error = "Product Not Found"
            return error

        try:    
            price = soup.find("div", class_="_30jeq3 _16Jk6d").text
            price = int(price.replace("₹", "").replace(",", ""))

        except:
            print("Price not Found")
            price = 0

        try:
            rev_ratings = soup.find_all("div", class_="_2afbiS")

            try:
                ratings = rev_ratings[0].get_text()
            
            except IndexError:
                print("Trying Different Method")

            try:    
                ratings = ratings.replace(" Ratings", "").replace(",", "").replace("&", "")
            
            except:
                print("Trying different Method")

            try:
                review = rev_ratings[1].get_text()

            except:
                print("Next")
            
            try:
                review = rev_ratings[1].get_text()
                review = review.replace(" Reviews", "").replace(",", "")

            

            except AttributeError:
                print("Review and Rating Error")


        except UnboundLocalError and IndexError:
            try:
                print("Trying diffrent method")
                rev_ratings = soup.find("span", class_="_2_R_DZ _2IRzS8").text
                rev_ratings = rev_ratings.split("and")
                ratings = int(rev_ratings[0].replace(" ratings", "").replace(",",""))
                review = int(rev_ratings[1].replace(" reviews", "").replace(",","").replace(" ", ""))
                print("Done with alternate try")

            except:
                ratings=0
                review = 0


        try:
            overall_rating = float(soup.find("div", class_="_3LWZlK _138NNC").text)

        except AttributeError:
            try:
                overall_rating = float(soup.find("div", class_="_2d4LTz").text)

            except AttributeError:
                overall_rating = 0.0

        try:
            image_link = soup.find("img", class_="_2r_T1I _396QI4")

            image_link = image_link.get("src")

        except AttributeError:
            try:
                image_link = soup.find("img", class_="_386cs4 _2amPTt _3qGmMb")
                image_link = image_link.get("src")
            
            except:
                image_link = soup.find("img", class_="_396cs4 _2amPTt _3qGmMb")
                image_link = image_link.get("src")

        try:
            reviewPercent = recomCalc(link)
            print(review)
        except:
            print("error review")

        pname = Product.objects.get(id = id)
        pname.product_name=name
        pname.price=int(price)
        pname.ratings=int(ratings)
        pname.reviews=int(review)
        pname.overall_ratings = float(overall_rating)
        pname.img_link=image_link
        pname.prating = reviewPercent[0]
        pname.nrating = reviewPercent[1]
        pname.save(update_fields=['product_name', 'price', 'ratings', 'reviews', 'overall_ratings', 'img_link', 'prating', 'nrating'])
        print("Product Saved")
        print(reviewPercent)
    except:
        error = "error"


    return



def recomCalc(link):
    #This is recommendation calculator for Flipkart Products, It returns Total Negative and Positive Recommendation
    headers={'Cache-Control': 'no-cache, must-revalidate'}
    r = requests.get(link.format(rn=time.time()), headers=headers)
    soup = BeautifulSoup(r.text, "lxml")
    word = "product-reviews"
    reviews = soup.find_all("a", class_=None)
    recomm = [80, 20]
    for r in reviews:
        rlink =  r.get('href')
        if word in rlink:
            rlink = "https://www.flipkart.com" + rlink
            headers={'Cache-Control': 'no-cache, must-revalidate'}
            r = requests.get(rlink.format(rn=time.time()), headers=headers)
            soup = BeautifulSoup(r.text, "lxml")
            word = "product-reviews"
            reviews = soup.find_all("div", class_="_1uJVNT")
            onestar = int(reviews[0].get_text().replace(",", ""))
            twostar = int(reviews[1].get_text().replace(",", ""))
            threestar = int(reviews[2].get_text().replace(",", ""))
            fourstar = int(reviews[3].get_text().replace(",", ""))
            fivestar = int(reviews[4].get_text().replace(",", ""))
            total = onestar + twostar + threestar + fourstar + fivestar
            postiveRecom = ((onestar + twostar) / total) * 100
            negeativeRecom = ((threestar + fourstar + fivestar) / total) * 100
            if negeativeRecom < 50:
                negeativeRecom = negeativeRecom + 1

            if postiveRecom < 50:
                postiveRecom = postiveRecom + 1
            recomm = [int(postiveRecom), int(negeativeRecom)]
            

    return recomm




def similarMatch(sourcename, searchname):
    #Similarity Match Function 
    n1 =sourcename.upper()
    n2 = searchname.upper()
    m = 0
    n = len(n1)
    nn = len(n2.split())

    if n<nn:
        n1 = n1.split()
        for p in n1:
            p = p.replace('(', '').replace(',','').replace(')','').replace('/','')
            f = n2.find(p)
            if f == -1:
                pass
            else:
                m = m+1
        per = (m/n) * 100

    else:
        n2 = n2.split()
        for p in n2:
            p = p.replace('(', '').replace(',','').replace(')','').replace('/','')
            f = n1.find(p)
            if f == -1:
                pass
            else:
                m = m+1
        per = (m/nn) * 100



    if per >= 50:
        msg ="Product Matched"

    else:
        msg ="Product Not Matched"




    return {'percentage': per, 'message':msg}



def compareProd(sourcename, source, category):
    links = []
    finalProd = ""
    product_name = ""
    msg = ""
    percentage = []
    prod = []
    name = []
    flip = Source.objects.get(name="Flipkart").id
    amz = Source.objects.get(name="Amazon").id
    prodl = []

    if source == "Amazon":
        print("Amazon Product Query")
        cprod = Product.objects.exclude(source = amz)
        for n in cprod:
            result = similarMatch(sourcename, n.product_name)
            per = int(result['percentage'])
            if per<50:
                msg = "Product Not Matched"
                
            else:
                name.append(n.product_name)
                links.append({n.link:per})
                percentage.append(per)
                msg = "Product Matched"
        product_name =[]   
        indexNumber = 0
        # Filtering from the best accurate match by finding the best percentage index in the list
        try:
            for x in range(5):
                print(x)
                for i in percentage:
                    if i >= indexNumber:
                        indexNumber =i
                indexNumber = percentage.index(indexNumber)
                prodl.append(links[indexNumber])
                percentage.pop(indexNumber)
                product_name.append(name[indexNumber])
                links.pop(indexNumber)
                name.pop(indexNumber)


        except:
            msg = "Product Not Found"


        if (msg == "Product Not Matched" or msg == "Product Not Found"):
            #Making the SOup of Flipkart
            # source = "Flipkart"
            finp = sourcename[0:80].replace('(', '').replace(')',"").replace(" ", "+").replace('/', '').replace(',', '').replace('''"''', '').replace('|', '').replace('[', '').replace(']', '').replace('.', '')
            urlm = f"https://www.flipkart.com/search?q={finp}"
            print(urlm)
            r = requests.get(urlm, headers=headers)
            soup = BeautifulSoup(r.text, "lxml")
            
            #Collecting all the product links
            link = soup.find_all('div', attrs={'class':'_4ddWXP'})

            #Collcting all product name
            nm = soup.find_all('a', attrs={'class', 's1Q9rs'})

            #Capturing the and matching similarity
            for n in nm:
                print("Going for name match")
                product_name = n.get('title')
                link = n.get('href')
                link = "https://www.flipkart.com" + link
                result = similarMatch(sourcename, product_name)
                per = int(result['percentage'])
                if per<50:
                    msg = "Product Not Matched"
                    
                else:
                    print(per)
                    print(link)
                    name.append(product_name)
                    links.append(link)
                    percentage.append(per)
                    msg = "Product Matched"
            product_name =[]   
            indexNumber = 0
            # Filtering from the best accurate match by finding the best percentage index in the list
   
            for i in percentage:
                if i >= indexNumber:
                    indexNumber =i
            indexNumber = percentage.index(indexNumber)
            prodl.append(links[indexNumber])
            percentage.pop(indexNumber)
            product_name.append(name[indexNumber])
            links.pop(indexNumber)
            name.pop(indexNumber)


        
            print(product_name)



            indexNumber = 0
            for l in links:
                r = requests.get(l, headers=headers)
                soup = BeautifulSoup(r.text, "lxml")

                try: 
                    price = soup.find("div", class_="_30jeq3 _16Jk6d").text
                    price = int(price.replace("₹", "").replace(",", ""))
                except:
                    print("Unable to Find Price")

                try:
                    rev_ratings = soup.find_all("div", class_="_2afbiS")
                    try:
                        ratings = rev_ratings[0].get_text()
                    
                    except IndexError:
                        print("Unable to Find Ratings, Trying another way")

                    try:    
                        ratings = ratings.replace(" Ratings", "").replace(",", "").replace("&", "")

                    except:
                        print("Ratings Unavailable")

                    try:
                        review = rev_ratings[1].get_text()

                    except:
                        print("Unable to Find Reviews, Trying another way")
                    
                    try:
                        review = rev_ratings[1].get_text()
                        review = review.replace(" Reviews", "").replace(",", "")

                    except AttributeError:
                        print("Incomplete Data-Skipping to Another Way")



                except UnboundLocalError and IndexError:
                    try:
                        print("Trying diffrent method")
                        rev_ratings = soup.find("span", class_="_2_R_DZ _2IRzS8").text
                        rev_ratings = rev_ratings.split("and")
                        ratings = int(rev_ratings[0].replace(" ratings", "").replace(",",""))
                        review = int(rev_ratings[1].replace(" reviews", "").replace(",","").replace(" ", ""))
                        print("Done with alternate try")

                    except:
                        print(Exception)
                        print("Invalid Product- Going to next product")
                        # continue


                try:
                    overall_rating = float(soup.find("div", class_="_3LWZlK _138NNC").text)

                except AttributeError:
                    try:
                        overall_rating = float(soup.find("div", class_="_2d4LTz").text)

                    except AttributeError:
                        print("Error")
                        # continue

                try:
                    image_link = soup.find("img", class_="_2r_T1I _396QI4")

                    image_link = image_link.get("src")

                except AttributeError:
                    try:
                        image_link = soup.find("img", class_="_386cs4 _2amPTt _3qGmMb")
                        image_link = image_link.get("src")
                    
                    except:
                        image_link = soup.find("img", class_="_396cs4 _2amPTt _3qGmMb")
                        image_link = image_link.get("src")

                subcat_raw = SubCategory.objects.filter(name=category)
                subcat = subcat_raw[0]
                cat = subcat_raw[0].category
                maincat = cat.maincategory
        
                reviewPercent = recomCalc(l)
                name = product_name[indexNumber]
                indexNumber = indexNumber + 1
                print(indexNumber)
                product = Product(
                    product_name=name, 
                    price=int(price), 
                    ratings=int(ratings), 
                    reviews=int(review), 
                    overall_ratings = float(overall_rating), 
                    link=l, 
                    img_link=image_link, 
                    query = sourcename, 
                    prating=reviewPercent[0],
                    nrating=reviewPercent[1],
                    maincategory=maincat,
                    category=cat,
                    subcategory=subcat,
                    )
                prodlist = {'name':name, 'price':int(price), 'ratings':int(ratings), 'review':int(review), 'overall_ratings':float(overall_rating), 'link':l, 'img_link':image_link}
                # product.save()
                # product.source.add(flip)
                prod.append(prodlist)


    
    elif source == "Flipkart":
        cprod = Product.objects.exclude(source = flip)
        for n in cprod:
            result = similarMatch(sourcename, n.product_name)
            per = int(result['percentage'])
            if per<50:
                msg = "Product Not Matched"
                
            else:
                name.append(n.product_name)
                links.append(n.link)
                percentage.append(per)
                msg = "Product Matched"
        product_name =[]   
        indexNumber = 0
        # Filtering from the best accurate match by finding the best percentage index in the list
        try:
            for x in range(5):
                print(x)
                for i in percentage:
                    if i >= indexNumber:
                        indexNumber =i
                indexNumber = percentage.index(indexNumber)
                prodl.append(links[indexNumber])
                percentage.pop(indexNumber)
                product_name.append(name[indexNumber])
                links.pop(indexNumber)
                name.pop(indexNumber)


        except:
            msg = "Product Not Found"


        if (msg == "Product Not Matched" or msg == "Product Not Found"):
            #Making the SOup of Amazon
            # source = "Flipkart"
            finp = sourcename.replace('(', '').replace(')',"").replace(" ", "+").replace('/', '').replace(',', '').replace('''"''', '').replace('|', '').replace('[', '').replace(']', '').replace('.', '')
            urlm = f"https://www.amazon.in/s?k={finp}"
            print(urlm)
            webpage = requests.get(urlm, headers=headers)
            soup = BeautifulSoup(webpage.content, 'html.parser')
            product_details = soup.find_all('h2', attrs={'class': "a-size-mini a-spacing-none a-color-base s-line-clamp-3"})

            links = []
            totalSaved = 0
            total_n = 0
            prodname = []
            productname = []

            #Getting Products Link****************************************************************************
            for i in product_details:
                name = i.find_all('span')
                pnm = ""

                for n in name:
                    pname = n.text
                    pnm = pnm + pname
                prodname.append(pnm)

                i = i.find('a', attrs={'class':'a-link-normal s-underline-text s-underline-link-text s-link-style a-text-normal'})
                i = i.get('href')
                i = str(i)
                links.append(i)
                exc1 = "/sspa/clic"
                exc2 = "https://aa"

                c = 0
                for l in links:
                    cond = l[0:10]
                    print(c)

                    if cond == exc1:
                        links.pop(c)
                        prodname.pop(c)

                    elif cond == exc2:
                        links.pop(c)
                        prodname.pop(c)

                    else:
                        print(prodname[c])
                        print(l)


                    c = c + 1

            for p in prodname:
                c = 0
                print(p)
                print("\n\n")
                result = similarMatch(sourcename, p)
                per = int(result['percentage'])
                if per<50:
                    msg = "Product Not Matched"
                    links.pop(c)
                else:
                    name.append(product_name)
                    percentage.append(per)
                    msg = "Product Matched"
                c  = c +1
            indexNumber = 0
            #Filtering from the best accurate match by finding the best percentage index in the list
            try:
                for i in percentage:
                    if i >= indexNumber:
                        indexNumber = i
                indexNumber = percentage.index(indexNumber)
                prodl.append(links[indexNumber])
                percentage.pop(indexNumber)
                product_name.append(name[indexNumber])
                links.pop(indexNumber)
                name.pop(indexNumber)
            
            except:
                msg = "Product Not Found"

            print(prodl)

            for l in prodl:
                source = "Amazon"
                url = "https://www.amazon.in" + l
                print(url)
                webpage = requests.get(url, headers=headers)
                soup = BeautifulSoup(webpage.content, 'html.parser')
                product = Product.objects.all()
                totalSaved = 0
                o_rating =0
                ft_rating = 0

                #Getting Product Name
                product_name = soup.find('span', attrs={'class': "a-size-large product-title-word-break"}).text.strip()

                #Getting Product Image
                product_img = soup.find('div', attrs={'class': "imgTagWrapper"})
                img_option = json.loads(product_img.contents[1]['data-a-dynamic-image'])
                product_img = sorted(img_option.keys())[-1]
                

                try:
                    #Getting Product Price
                    product_price = soup.find('span', attrs={'class': "a-price-whole"}).text.replace(",", "")
                except:
                    pass
                
                try:
                #Getting Overall Rating
                    rating_rev = soup.find('span', attrs={'class': "reviewCountTextLinkedHistogram noUnderline"}).text.strip()
                    o_rating = rating_rev.split(" ")
                    o_rating = o_rating[0]

                #Getting Total Ratings
                    t_ratings = soup.find('span', attrs={'id': 'acrCustomerReviewText'}).text.replace(" ratings", "").split(" ")
                    ft_rating = int(t_ratings[0].replace(",", ""))

                #Getting Negative & Positive Rating
                    pnrating = soup.find('span', attrs={'class': 'cr-widget-TitleRatingsAndHistogram'})
                    star5 = pnrating.find('a', attrs={'class':'a-link-normal 5star'}).get('title').split(" ")[0]
                    star4 = pnrating.find('a', attrs={'class':'a-link-normal 4star'}).get('title').split(" ")[0]
                    star3 = pnrating.find('a', attrs={'class':'a-link-normal 3star'}).get('title').split(" ")[0]
                    star2 = pnrating.find('a', attrs={'class':'a-link-normal 2star'}).get('title').split(" ")[0]
                    star1 = pnrating.find('a', attrs={'class':'a-link-normal 1star'}).get('title').split(" ")[0]
                    precom = int(star5.replace("%", "")) + int(star4.replace("%", ""))
                    nrecom = int(star3.replace("%", "")) + int(star2.replace("%", "")) + int(star1.replace("%", ""))

                except:
                    precom = 0
                    nrecom = 0
                

                #Getting Product Description
                print(url)
                try:
                    desc = soup.find('div', attrs={'class' : 'a-row feature'})
                    print(desc)
                    try:
                        desc = desc.find('span').text
                        print(desc)
                    except:
                        desc = desc.find('p').text
                        print(desc)

                except:
                    desc = soup.find_all('div', attrs={'class' : 'aplus-module-wrapper aplus-3p-fixed-widthaplus-module-wrapper aplus-3p-fixed-width'})
                    for d in desc:
                        d = d.find('div', attrs = {'class': 'a-spacing-base'}).text
                        desc =  d + d


                #Getting Brand Name
                brand = soup.find('tr', attrs={'class':'a-spacing-small po-brand'})
                brand = brand.find('span', attrs={'class':'a-size-base po-break-word'}).text
                brand = brand.capitalize()



                #Getting the Categories
                subcat = SubCategory.objects.filter(name__icontains =category)
                print(subcat)
                sub = subcat[0]
                cat = subcat[0].category
                maincat = cat.maincategory

                #Getting the source
                source = Source.objects.get(name = source)

                #Getting the Brand Name

                try:
                    brand = Brand.objects.filter(name__icontains=brand)[0]
                
                except:
                    brand = Brand(name = brand)
                    brand.save()


                #Saving The Data
                product_price = product_price.replace(".", "")
                product = Product(
                    product_name=product_name, 
                    price=int(product_price), 
                    ratings=int(ft_rating),

                    #Adding Default Review Count Because Reveiw count is not available on the website
                    reviews=50, 

                    overall_ratings = float(o_rating), 
                    link=url, 
                    img_link=product_img, 
                    query = sourcename, 
                    prating=precom,
                    nrating=nrecom,
                    maincategory=maincat,
                    category=cat,
                    subcategory=sub,
                    desc = desc,
                    brand = brand,
                    )
                # prodlist = {'name':product_name, 'price':int(product_price), 'ratings':int(ft_rating), 'review':50, 'overall_ratings':float(o_rating), 'link':url, 'img_link':product_img}
                product.save()
                product.source.add(source)
                prod.append(product)
                totalSaved = totalSaved + 1



                
            
            else:
                msg = "Product Not Found"

        return [prod, msg]





        
    


def amazonscript(search, category):
    query = search.replace(" ", "+")
    url = f"https://www.amazon.in/s?k={query}"
    webpage = requests.get(url, headers=headers)
    soup = BeautifulSoup(webpage.content, 'html.parser')
    product_link = soup.find_all('a', attrs={'class': "a-link-normal s-underline-text s-underline-link-text s-link-style a-text-normal"})
    link = []
    totalSaved = 0
    #Getting Products Link****************************************************************************
    for i in product_link:
        i = i.get('href')
        i = str(i)
        cond = i[0:10]
        exc1 = "/sspa/clic"
        exc2 = "https://aa"
        if( exc1 != cond and exc2  != cond):
            link.append(i)

    #Single Product Scraping******************************************************************************
    for l in link:
        result = amazonSingle(l, category, search)
        totalSaved = totalSaved + result[1]
        print(f"{totalSaved} products saved so far...")
    
    print(f"Done Fetching {len(link)} products {totalSaved}")
    return [len(link), totalSaved]

def amazonSingle(link, category, search):
    source = "Amazon"
    url = "https://www.amazon.in" + link
    print(url)
    webpage = requests.get(url, headers=headers)
    soup = BeautifulSoup(webpage.content, 'html.parser')
    product = Product.objects.all()
    totalSaved = 0
    o_rating =0
    ft_rating = 0

    #Getting Product Name
    product_name = soup.find('span', attrs={'class': "a-size-large product-title-word-break"}).text.strip()

    #Getting Product Image
    product_img = soup.find('div', attrs={'class': "imgTagWrapper"})
    img_option = json.loads(product_img.contents[1]['data-a-dynamic-image'])
    product_img = sorted(img_option.keys())[-1]

    #Getting Product Price
    product_price = soup.find('span', attrs={'class': "a-price-whole"}).text.replace(",", "")
    try:
    #Getting Overall Rating
        rating_rev = soup.find('span', attrs={'class': "reviewCountTextLinkedHistogram noUnderline"}).text.strip()
        o_rating = rating_rev.split(" ")
        o_rating = o_rating[0]

    #Getting Total Ratings
        t_ratings = soup.find('span', attrs={'id': 'acrCustomerReviewText'}).text.replace(" ratings", "").split(" ")
        ft_rating = int(t_ratings[0].replace(",", ""))

    #Getting Negative & Positive Rating
        pnrating = soup.find('span', attrs={'class': 'cr-widget-TitleRatingsAndHistogram'})
        star5 = pnrating.find('a', attrs={'class':'a-link-normal 5star'}).get('title').split(" ")[0]
        star4 = pnrating.find('a', attrs={'class':'a-link-normal 4star'}).get('title').split(" ")[0]
        star3 = pnrating.find('a', attrs={'class':'a-link-normal 3star'}).get('title').split(" ")[0]
        star2 = pnrating.find('a', attrs={'class':'a-link-normal 2star'}).get('title').split(" ")[0]
        star1 = pnrating.find('a', attrs={'class':'a-link-normal 1star'}).get('title').split(" ")[0]
        precom = int(star5.replace("%", "")) + int(star4.replace("%", ""))
        nrecom = int(star3.replace("%", "")) + int(star2.replace("%", "")) + int(star1.replace("%", ""))

    except:
        precom = 0
        nrecom = 0
    

    #Getting Product Description
    print(url)
    try:
        desc = soup.find('div', attrs={'class' : 'a-row feature'})
        print(desc)
        try:
            desc = desc.find('span').text
            print(desc)
        except:
            desc = desc.find('p').text
            print(desc)

    except:
        desc = soup.find_all('div', attrs={'class' : 'aplus-module-wrapper aplus-3p-fixed-widthaplus-module-wrapper aplus-3p-fixed-width'})
        for d in desc:
            d = d.find('div', attrs = {'class': 'a-spacing-base'}).text
            desc =  d + d


    #Getting Brand Name
    brand = soup.find('tr', attrs={'class':'a-spacing-small po-brand'})
    brand = brand.find('span', attrs={'class':'a-size-base po-break-word'}).text
    brand = brand.capitalize()



    #Adding Products to the database
    if float(o_rating) >= 4.0 and int(ft_rating) >= 500:

        #Getting the Categories
        subcat = SubCategory.objects.filter(name__icontains =category)
        print(subcat)
        sub = subcat[0]
        cat = subcat[0].category
        maincat = cat.maincategory

        #Getting the source
        source = Source.objects.get(name = source)

        #Getting the Brand Name

        try:
            brand = Brand.objects.filter(name__icontains=brand)[0]
        
        except:
            brand = Brand(name = brand)
            brand.save()


        #Saving The Data
        product_price = product_price.replace(".", "")
        product = Product(
            product_name=product_name, 
            price=int(product_price), 
            ratings=int(ft_rating),

            #Adding Default Review Count Because Reveiw count is not available on the website
            reviews=50, 

            overall_ratings = float(o_rating), 
            link=url, 
            img_link=product_img, 
            query = search, 
            prating=precom,
            nrating=nrecom,
            maincategory=maincat,
            category=cat,
            subcategory=sub,
            desc = desc,
            brand = brand,
            )
        product.save()
        product.source.add(source)
        totalSaved = totalSaved + 1

    return [product, totalSaved]


def meshoscript(search):
    product_main = []


    finp = search.replace(" ", "+")

    i = 0
    i = i+1

    print(f"Page {i}")
    urlm = f"https://www.amazon.in/s?k={finp}&ref=nb_sb_noss"
    r = requests.get(urlm)
    print(urlm)

    soup = BeautifulSoup(r.text, "lxml")
    

    links = soup.find_all("div", class_="sc-hLBbgP")
    link = links.get("href")
    product_main.append(link)
    np = soup.find_all("a", class_="_1LKTO3")


def ajioscript(search):
    "Error"

def myntrascript(search):
    "pass"