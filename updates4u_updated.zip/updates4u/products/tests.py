

dja = r"\media\uploads\amazon"
djf = r"/media/uploads/flipka"

print(len(djf))