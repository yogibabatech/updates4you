sdjb = "MuscleBlaze L- Glutamine, Post Workout Recovery Powder for Adults"

print(len(sdjb))