from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt
from products.program.scrape import productcomp, flipkartProUp, amazonscript, compareProd, similarMatch
from .models import Product, Category, MainCategory, SubCategory
from products.program.compare import compareP

def home(request):
    if request.method == "GET":
        query = request.GET
        if 'wheyprotein' in request.GET:
            sub = SubCategory.objects.filter(name__icontains = "whey protein")
            query = sub[0].name
            sub = sub[0].id
            product = Product.objects.filter(subcategory = sub)

        

        elif 'creatine' in request.GET:
            sub = SubCategory.objects.filter(name__icontains = "creatine")
            query = sub[0].name
            sub = sub[0].id
            product = Product.objects.filter(subcategory = sub)
     
        elif 'bcaa' in request.GET:
            sub = SubCategory.objects.filter(name__icontains = "bcaa")
            query = sub[0].name
            sub = sub[0].id
            product = Product.objects.filter(subcategory = sub)
        
        elif 'fatburner' in request.GET:
            sub = SubCategory.objects.filter(name__icontains = "Fat Burner")
            query = sub[0].name
            print(sub)
            sub = sub[0].id
            product = Product.objects.filter(subcategory = sub)

        else:
            product = Product.objects.all().order_by('-created_at')[0:20]
            return render(request, "index.html", {'data':product, 'query': "All Products"})
        
        catlist = SubCategory.objects.all()
        
        return render(request, "post.html", {'data':product, 'cat':catlist, 'query':query})
    
    elif request.method == "POST":
        if 'productq' in request.method == "POST":
            print("Search2")
            data = request.POST
            data = data.get('productq')
            if Product.objects.filter(product_name__contains = data).exists():
                product = Product.objects.filter(product_name__contains = data).values()
                return render(request, "post.html", {'data':product})


        elif 'searchq' in request.method == "POST":
            print("Search1")
            data = request.POST
            data = data.get('searchq')
            if Product.objects.filter(product_name__contains = data).exists():
                product = Product.objects.filter(product_name__contains = data).values()
                return render(request, "post.html", {'data':product})

        
        elif 'wheyprotein' in request.method == "GET":
            print   ("going for Whey Protein")
            sub = SubCategory.objects.filter(name__icontains = "whey protein").id
            product = Product.objects.get(subcategory = sub)
            return render(request, "post.html", {'data':product})



        else:
            product = Product.objects.all().order_by('-created_at')[0:20]
            return render(request, "index.html", {'data':product})


def contact(request):
    return render(request, 'contact.html')

def preworkout(request):
    sub = SubCategory.objects.filter(name__icontains = "Preworkout")
    print(sub)
    sub = sub[0].id
    product = Product.objects.filter(subcategory = sub)
    catlist = SubCategory.objects.all()
    return render(request, "post.html", {'data':product, 'cat':catlist, 'query':'Pre Workout'})


def searchMatch(query):

    # querys = query
    # queryr = list(reversed(querys))
    product= []
    msg = {"msg":"Product Not Found"}
    q = ""
    catid = "Not Found"
    data = [product, [msg], [q]]
    queryres = Product.objects.filter(product_name__icontains = query)

    if queryres:
            print("Product Name Found")
            q = queryres[0].category.id
            product = queryres
            msg['msg'] = f"Found {len(product)} products"
            data = [product, [msg], [q]]

    else:
            q = query
            print(q)


            mcat = MainCategory.objects.filter(name__icontains = q)

            ccat = Category.objects.filter(name__icontains = q)

            scat = SubCategory.objects.filter(name__icontains = q)

            
            
            
            
            if mcat:
                print(mcat)
                for i in mcat:
                    print(i)
                    catid = i.id
                    q = ['mcat', i]
                    product = Product.objects.filter(maincategory_id = catid).order_by("-created_at")
  
                    
                    


            elif scat:
                print("mac1")
                for i in scat:
                    catid = i.id
                    q = ['scat', i]
                    product = Product.objects.filter(subcategory_id = catid).order_by("-created_at")


            elif ccat:
                print("mac2")
                for i in ccat:
                    catid = i.id
                    q = ['ccat', i]
                    product = Product.objects.filter(category_id = catid).order_by("-created_at")

            else:
                print("mac3")
                product = Product.objects.filter(product_name__icontains = q).order_by("-created_at")
                data = [product, [msg], [q]]


    if product:
        count = (f"Total {len(product)} products found")
        msg= {"msg":count}
        data = [product, [msg], [q], [catid]]
   

    elif not product:
        print("Checking with name")
        productname = Product.objects.filter(product_name__icontains = query).order_by("-created_at")
        if productname:
            print("Product Name Found")
            product = productname
            catid = product.category_id
            count = (f"Total {len(product)} products found")
            msg= {"msg":count}
            data = [product, [msg], [q]]


    else:
        print("P Not Found")
        msg= {"msg":"Product Not Found"}
        data = [product, [msg], [q]]
            
    return data


def filterProds():
    pass



def search(request):
    minprice = 0
    maxprice = 10000
    if request.method == 'GET':
        if 'productq' in request.GET:
            query = request.GET['productq']
            product = searchMatch(query)
            product = product[0]

                
        elif 'sort' or 'query' in request.GET:
            print("SOrting")
            data = request.GET
            data1 = data['sort']
            query = data['query']
            search = searchMatch(query)
            product = search[0]
            msg = "Product Not Found"
            svalue ={"borated":"selected"}
            print("SOrting prouct")

            try:    
                if data1 == "borated":
                    print("going good")
                    product = product.order_by('-overall_ratings').values()
                    print(product)
                    svalue = {"borated":"selected"}

                elif data1 == "brated":
                    product = product.order_by('-ratings').values()
                    svalue = {"brated":"selected"}

                elif data1 == "mreview":
                    product = product.order_by('-reviews').values()
                    svalue = {"mreview":"selected"}
            except:
                pass
        
            return render(request, "post.html", {'data':product, 'query':query, 'minprice':minprice, 'maxprice':maxprice, 'svalue':svalue, 'msg':msg})

        elif "min-input" in request.GET:
            print("Filtering Process Command")
            data = request.GET
            data2 = data['query']
            minprice = int(data['min-input'])
            maxprice = int(data['max-input'])
            print(data)
            ratinginput = None
            reviewinput = None

            if 'ratingFilter' in data:
                ratinginput = data["ratingFilter"]
                print(ratinginput)
            
            if "reviewFilter" in data:
                reviewinput = data["reviewFilter"]
                print(reviewinput)
            
            checklist = {}

            if ratinginput == None:
                print("Rating Is None")
                ratinginput = 0
            elif int(ratinginput):
                print(ratinginput)
                if int(ratinginput) == 500:
                    checklist0 = {'ratinginput500':'checked'}
                elif int(ratinginput) == 1000:
                    checklist0 = {'ratinginput1000':'checked'}
                elif int(ratinginput) == 2000:
                    checklist0 = {'ratinginput2000':'checked'}
                elif int(ratinginput) == 5000:
                    checklist0 = {'ratinginput5000':'checked'}
                elif int(ratinginput) == 10000:
                    checklist0 = {'ratinginput10000':'checked'}
                checklist.update(checklist0)
                print(checklist)


            if reviewinput == None:
                print("review Is None")
                reviewinput = 0
            elif reviewinput:
                print("Going for Review")
                print(reviewinput)

                if int(reviewinput) == 500:
                    checklist1 = {'reviewinput500':'checked'}
                elif int(reviewinput) == 1000:
                    checklist1 = {'reviewinput1000':'checked'}
                elif int(reviewinput) == 2000:
                    print("Review is more than 2000")
                    checklist1 = {'reviewinput2000':'checked'}
                elif int(reviewinput) == 5000:
                    checklist1 = {'reviewinput5000':'checked'}
                elif int(reviewinput) == 10000:
                    checklist1 = {'reviewinput10000':'checked'}
                checklist.update(checklist1)


            cat = searchMatch(data2)
            print(cat)
        
            product = Product.objects.filter(product_name__contains = data2).filter(price__gte = minprice).filter(price__lte=maxprice).filter(reviews__gte=int(reviewinput)).filter(ratings__gte=int(ratinginput)).values()
            return render(request, "post.html", {'data':product, 'query':data2, 'minprice':minprice, 'maxprice':maxprice, 'ratingvalue':ratinginput, 'reviewvalue':reviewinput, 'check' : checklist})



        else:
            return render(request, "index.html")
    return render(request, "post.html", {'data':product, 'query':query, 'minprice':minprice, 'maxprice':maxprice})
    
def singleproduct(request, id):


    try:
        prod = Product.objects.filter(id = id)
        print(prod)
        prodSlider = prod[0].category.id
        
        prod = prod[0]
        scrollprod = Product.objects.filter(category_id = prodSlider).order_by('?')[0:20]
    except:
        pass
    return render(request, 'singleproduct.html', {'prod':prod, 'scroll':scrollprod})


def updateProduct(request, id):
    prod = Product.objects.get(id = id)
    source = prod.source.all()
    link = prod.link
    for s in source:
        try:
            if s.name.upper() == "AMAZON":
                print("Updating Product From Amazon")
                pass

            
            elif s.name.upper() == "FLIPKART":
                print("Updating Product From Flipkart")
                flipkartProUp(link, id)
    
            else:
                print("Updating Product From Flipkart")
                flipkartProUp(link, id)
        except:
            pass
 
    prodSlider = prod.category_id
    scrollprod = Product.objects.filter(category_id = prodSlider).order_by('?')[0:20]
    print(len(scrollprod))
    prod = Product.objects.get(id = id)
    return render(request, 'singleproduct.html', {'prod':prod, 'scroll':scrollprod})


def product(request):
    minprice = 0
    maxprice = 10000
    if request.method == 'GET':
        if 'sort' in request.GET:
            data = request.GET
            data1 = data['sort']
            query = data['query']
            search = searchMatch(query)
            product = search[0]
            msg = "Product Not Found"
            svalue ={"borated":"selected"}
            print("SOrting prouct")

            try:    
                if data1 == "borated":
                    product = product.order_by('-overall_ratings').values()
                    svalue ={"borated":"selected"}

                elif data1 == "brated":
                    product = product.order_by('-ratings').values()
                    svalue = {"brated":"selected"}

                elif data1 == "mreview":
                    product = product.order_by('-reviews').values()
                    svalue = {"mreview":"selected"}
            except:
                pass

            return render(request, "post.html", {'data':product, 'query':query, 'minprice':minprice, 'maxprice':maxprice, 'svalue':svalue, 'msg':msg})

        elif "min-input" in request.GET:
            print("Filtering Process Command")
            data = request.GET
            data2 = data['query']
            try:
                 minprice = int(data['min-input'])
                 maxprice = int(data['max-input'])
            except:
                    pass
            print(data)
            ratinginput = None
            reviewinput = None

            if 'ratingFilter' in data:
                ratinginput = data["ratingFilter"]
                print(ratinginput)
            
            if "reviewFilter" in data:
                reviewinput = data["reviewFilter"]
                print(reviewinput)
            
            checklist = {}

            if ratinginput == None:
                print("Rating Is None")
                ratinginput = 0
            elif int(ratinginput):
                print(ratinginput)
                if int(ratinginput) == 500:
                    checklist0 = {'ratinginput500':'checked'}
                elif int(ratinginput) == 1000:
                    checklist0 = {'ratinginput1000':'checked'}
                elif int(ratinginput) == 2000:
                    checklist0 = {'ratinginput2000':'checked'}
                elif int(ratinginput) == 5000:
                    checklist0 = {'ratinginput5000':'checked'}
                elif int(ratinginput) == 10000:
                    checklist0 = {'ratinginput10000':'checked'}
                checklist.update(checklist0)
                print(checklist)


            if reviewinput == None:
                print("review Is None")
                reviewinput = 0
            elif reviewinput:
                print("Going for Review")
                print(reviewinput)

                if int(reviewinput) == 500:
                    checklist1 = {'reviewinput500':'checked'}
                elif int(reviewinput) == 1000:
                    checklist1 = {'reviewinput1000':'checked'}
                elif int(reviewinput) == 2000:
                    print("Review is more than 2000")
                    checklist1 = {'reviewinput2000':'checked'}
                elif int(reviewinput) == 5000:
                    checklist1 = {'reviewinput5000':'checked'}
                elif int(reviewinput) == 10000:
                    checklist1 = {'reviewinput10000':'checked'}
                checklist.update(checklist1)


            cat = searchMatch(data2)
            print("Going 1")

            product = Product.objects.filter(product_name__contains = data2).filter(price__gte = minprice).filter(price__lte=maxprice).filter(reviews__gte=int(reviewinput)).filter(ratings__gte=int(ratinginput)).order_by('-created_at').values()
            return render(request, "post.html", {'data':product, 'query':data2, 'minprice':minprice, 'maxprice':maxprice, 'ratingvalue':ratinginput, 'reviewvalue':reviewinput, 'check' : checklist})

        else:
            print("Going 2")
            product = Product.objects.all()[0:20]
            return render(request, "post.html", {'data':product})


def about (request):
    return render(request, 'about.html')

def manage (request):
    prod = Product.objects.all()
    cat = SubCategory.objects.all()
    subcat = ""
    result = [0,0]
    if request.method == "GET":
        selected_data = request.GET.getlist('selected_data[]')
        response_data = {'message': 'Data applied successfully.'}
        print(selected_data)

        
        if 'finder' in request.GET:
            search = request.GET['finder']
            sub = request.GET['add-cat']
            subcat = SubCategory.objects.get(name = sub)
            subcat = subcat.id
            result = amazonscript(search, sub)
            prod = Product.objects.filter(subcategory = subcat).order_by('-created_at')[0:result[1]]

            
            
        elif 'filter' in request.GET:
            f_data = request.GET['filter']
            print(f_data)
            subcat = SubCategory.objects.filter(name__icontains = f_data)[0].id
            prod = Product.objects.filter(subcategory = subcat)
            subcat = f_data

        elif 'delete_id' in request.GET:
            print("deleting data")
            d_data = request.GET['delete_id']
            p = Product.objects.get(id=d_data)
            p_id = p.subcategory.id
            prod = Product.objects.filter(subcategory = p_id)
            subcat = p.subcategory.name
            print(p)
            p.delete()

        elif 'update_id' in request.GET:
            print("Updating data")
            d_data = request.GET['update_id']
            c_data = request.GET['category']
            c_id = SubCategory.objects.get(name = c_data)
            p = Product.objects.get(id=d_data)
            cat_id = p.subcategory.id
            p.subcategory = c_id
            p.save()
            print(p.subcategory)
            prod = Product.objects.filter(subcategory =cat_id)
            # subcat = prod.subcategory.name

        

    return render(request, 'manage.html', {'prod':prod, 'cat':cat, 'subcat': subcat})


def compare(request):
    compare = []
    msg = ""
    finalcomp = []
    if request.method == "GET":
        if "compareId" in request.GET:
            sourceid = request.GET['prodid']
            print("compareiddddddddddd")
            id = request.GET['compareId']
            prod = Product.objects.get(id=sourceid)
            compare = Product.objects.filter(id=sourceid)

            finalcomp = Product.objects.get(id=id)
            src = finalcomp.source.all()[0].img.url
            srcn = finalcomp.source.all()[0].name

            
            finalcomp =  {'source':src,
                          'sourcename':srcn,
                          'product_name':finalcomp.product_name, 
                          'price':finalcomp.price,
                          'overall_ratings':finalcomp.overall_ratings,
                          'ratings':finalcomp.ratings,
                          'reviews':finalcomp.reviews,
                          'nrating':finalcomp.nrating,
                          'prating':finalcomp.prating,
                          'link':finalcomp.link,
                          }
            
            print(finalcomp)

            import json
            return JsonResponse(finalcomp)
        

        else:
            print("Comparing")
            sourceid = request.GET['product_id']
            sourcename = Product.objects.get(id = sourceid).product_name
            category = Product.objects.get(id = sourceid).subcategory.name
            source = Product.objects.get(id = sourceid).source.all()
            if not source:
                msg = "Product Not Found"
                
            else:
                source = source[0].name
                compprod = [Product.objects.filter(id = sourceid), "Product Matched"]
                compare = compareP(sourceid)
                msg = compprod[1]

            prod = Product.objects.get(id = sourceid)
        prodSlider = prod.category.id
        scrollprod = Product.objects.filter(category = prodSlider).order_by('?')[0:20]

    
    return render(request, 'singleproduct.html', {'prod':prod, 'comp':compare, 'fcomp':finalcomp ,'scroll':scrollprod, 'msg':msg} )